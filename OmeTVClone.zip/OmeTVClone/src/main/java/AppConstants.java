import java.awt.*;

public interface AppConstants {


    Dimension DEFAULT_CONTAINER_DIMENSION = new Dimension(800,600);
    Dimension DEFAULT_VIDEO_SIZE = new Dimension(480,360);
    Dimension DEFAULT_CONTROLS_CONTAINER_DIMENSION = new Dimension(700, 120);
    Dimension DEFAULT_CHAT_CONTAINER_DIMENSION = new Dimension(480, 120);










}
