public enum EventType {

    START_BTN,
    STOP_BTN,
}
