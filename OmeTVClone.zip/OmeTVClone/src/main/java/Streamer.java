import org.bytedeco.javacv.Frame;
import org.bytedeco.javacv.Java2DFrameConverter;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.concurrent.BlockingQueue;


public class Streamer extends Thread {

    private String ip;
    private BlockingQueue<Frame> frames;
    private DatagramSocket udpSocket;
    private int port;
    private boolean running;


    public Streamer(BlockingQueue<Frame> frames, String ip, int port) {
        this.frames = frames;
        this.ip = ip;
        this.port = port;
        this.running = true;
        try {
            this.udpSocket = new DatagramSocket();
        } catch (SocketException e) {
            System.out.println("Unable to create datagram socket");
        }
    }




    @Override
    public void run() {

        Java2DFrameConverter converter = new Java2DFrameConverter();
        while (running) {

            Frame frame = null;
            try {
                frame = frames.take();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if (frame != null) {
                BufferedImage bufferedImage = converter.convert(frame);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                try {
                    ImageIO.write(bufferedImage, "jpg", baos);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                byte[] bytes = baos.toByteArray();

                int packetSize = 65507 - 8;  // subtract the size of the header
                int totalPackets = (bytes.length + packetSize - 1) / packetSize;  // compute the total number of packets

                ByteBuffer packetBuffer = ByteBuffer.allocate(packetSize + 8);  // create a ByteBuffer for the packet

                for (int i = 0; i < bytes.length; i += packetSize) {
                    packetBuffer.clear();  // clear the ByteBuffer

                    int actualPacketSize = Math.min(packetSize, bytes.length - i);

                    packetBuffer.putInt(i / packetSize);  // put the packet number
                    packetBuffer.putInt(totalPackets);  // put the total number of packets
                    packetBuffer.put(bytes, i, actualPacketSize);  // put the actual data

                    byte[] packetBytes = packetBuffer.array();
                    DatagramPacket packet = null;
                    try {
                        packet = new DatagramPacket(packetBytes, 8 + actualPacketSize, InetAddress.getByName(ip), port);
                    } catch (UnknownHostException e) {
                        e.printStackTrace();
                    }

                    try {
                        udpSocket.send(packet);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }


    public void stopStreamer() {
        running = false;
    }


}
